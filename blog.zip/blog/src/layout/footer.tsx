export default function Footer() {
	return <footer></footer>
}
