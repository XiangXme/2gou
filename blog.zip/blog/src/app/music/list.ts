export const list = [
	{
		name: '我的悲伤是水做的',
		iframe: `<iframe src="//player.bilibili.com/player.html?isOutside=true&aid=115259171935419&bvid=BV1HrJ9zXEvF&cid=32603177515&p=1" scrolling="no" border="0" frameborder="no" framespacing="0" allowfullscreen="true"></iframe>`
	}
]
